############################################################
# plots_grades.R
# Grades NCI-CTCAE v5.0 — Neutropénie + Thrombocytopénie
# Fonctions :
#   save_grade_plots()    → rat  (Figure 3 style)
#   save_grade_figure4c() → humain population (Figure 4c)
############################################################
library(ggplot2)
library(gridExtra)
library(grid)
library(deSolve)

# ════════════════════════════════════════════════════════
# SEUILS NCI-CTCAE v5.0
# ════════════════════════════════════════════════════════
# Neutropénie (10^9 cells/L) — NCI-CTCAE v5.0 + Fornari Fig. 4
# G1: <LLN-1.5  G2: <1.5-1.0  G3: <1.0-0.5  G4: <0.5
NEUT_THRESHOLDS <- c(G1 = 1.5, G2 = 1.0, G3 = 1.0, G4 = 0.5)

# Thrombocytopénie (10^9 cells/L) — NCI-CTCAE v5.0 + Fornari Fig. 4
# G1: <LLN-75   G2: <75-50    G3: <50-25    G4: <25
PLT_THRESHOLDS  <- c(G1 = 75,  G2 = 50,  G3 = 50,  G4 = 25)

# Couleurs des grades
GRADE_COLORS <- c(G1 = "#fee08b", G2 = "#fc8d59",
                  G3 = "#d73027", G4 = "#7b0404")

# ════════════════════════════════════════════════════════
# 1. FONCTION UTILITAIRE — grade d'une valeur scalaire
# ════════════════════════════════════════════════════════
# NCI-CTCAE v5.0 — confirmé par Fornari 2019 Figure 4
# Neutrophiles : G3 < 1.0,  G4 < 0.5  (x10^9/L)
# Plaquettes   : G3 < 50,   G4 < 25   (x10^9/L)
assign_grade_neut <- function(x) {
  ifelse(x <  0.5, 4,
  ifelse(x <  1.0, 3,
  ifelse(x <  1.5, 2,
  ifelse(x <  2.0, 1, 0))))
}

assign_grade_plt <- function(x) {
  ifelse(x <   25, 4,
  ifelse(x <   50, 3,
  ifelse(x <   75, 2,
  ifelse(x <  150, 1, 0))))
}

# Nadir grade = grade de la valeur minimale
nadir_grade_neut <- function(vec) assign_grade_neut(min(vec, na.rm = TRUE))
nadir_grade_plt  <- function(vec) assign_grade_plt( min(vec, na.rm = TRUE))

# ════════════════════════════════════════════════════════
# 2. PANNEAU GRADE — courbe + bandes de grade colorées
# ════════════════════════════════════════════════════════
plot_grade_panel <- function(sim, yvar, title, color,
                             thresholds,
                             baseline  = NULL,
                             dose_days = NULL) {

  y     <- sim[[yvar]]
  days  <- sim$days
  ymin  <- min(thresholds) * 0.1
  ymax  <- max(y, na.rm = TRUE) * 3
  ymin  <- max(ymin, 1e-3)

  breaks_y <- 10^seq(floor(log10(ymin)), ceiling(log10(ymax)), by = 1)

  df <- data.frame(x = days, y = pmax(y, ymin * 0.5))

  # Seuils — AVANT la chaine ggplot (pas d'assignation dans ggplot())
  # Neutrophiles : G3=1.0, G4=0.5  |  Plaquettes : G3=50, G4=25
  thr_G1 <- as.numeric(thresholds["G1"])   # 1.5  / 75
  thr_G2 <- as.numeric(thresholds["G2"])   # 1.0  / 50
  thr_G3 <- thr_G2                          # seuil G3 = borne inférieure G2
  thr_G4 <- as.numeric(thresholds["G4"])   # 0.5  / 25

  p <- ggplot() +

    # Bandes de grade
    annotate("rect", xmin=-Inf, xmax=Inf,
             ymin=ymin,    ymax=thr_G4,
             fill=GRADE_COLORS["G4"], alpha=0.15) +
    annotate("rect", xmin=-Inf, xmax=Inf,
             ymin=thr_G4,  ymax=thr_G3,
             fill=GRADE_COLORS["G3"], alpha=0.13) +
    annotate("rect", xmin=-Inf, xmax=Inf,
             ymin=thr_G3,  ymax=thr_G1,
             fill=GRADE_COLORS["G2"], alpha=0.09) +

    # Seuils G3 et G4 uniquement — comme Figure 4 article
    geom_hline(yintercept = c(thr_G3, thr_G4),
               linetype = "dashed", linewidth = 0.5,
               color = "black", alpha = 0.7) +

    # Labels G3 / G4
    annotate("text", x = max(days)*0.97, y = thr_G3*1.2,
             label="G3", size=2.8, color="grey30", hjust=1) +
    annotate("text", x = max(days)*0.97, y = thr_G4*1.2,
             label="G4", size=2.8, color="grey30", hjust=1) +

    # Courbe simulation
    geom_line(data = df, aes(x = x, y = y),
              color = color, linewidth = 1.0)

  # Baseline
  if (!is.null(baseline) && baseline > 0)
    p <- p + geom_hline(yintercept = baseline, linetype = "dashed",
                        color = "grey50", linewidth = 0.4, alpha = 0.5)

  # Doses
  if (!is.null(dose_days)) {
    vd <- dose_days[dose_days <= max(days)]
    if (length(vd) > 0)
      p <- p + geom_vline(xintercept = vd, linetype = "dotted",
                          color = "grey55", linewidth = 0.35, alpha = 0.55)
  }

  p +
    scale_y_log10(limits = c(ymin, ymax), breaks = breaks_y,
                  labels = scales::trans_format("log10",
                                                scales::math_format(10^.x))) +
    labs(title = title, x = "Time (d)",
         y = expression(10^9~cells~L^{-1})) +
    theme_bw(base_size = 9.5) +
    theme(panel.grid.minor = element_blank(),
          panel.grid.major = element_line(color = "grey92"),
          plot.title  = element_text(face = "bold", size = 9, hjust = 0.5),
          axis.title  = element_text(size = 7.5),
          axis.text   = element_text(size = 7))
}

# ════════════════════════════════════════════════════════
# 3. SAVE_GRADE_PLOTS — rat (Figure 3 style)
#    Retourne liste avec nadir/grade/pct pour console
# ════════════════════════════════════════════════════════
save_grade_plots <- function(sim, pars, file, titre_base,
                             dose_days = NULL,
                             width = 10, height = 5) {

  p_neut <- plot_grade_panel(
    sim, "Neut", "Neutrophils (NCI-CTCAE)", "#d7191c",
    NEUT_THRESHOLDS, pars$Neut0, dose_days
  )
  p_plt <- plot_grade_panel(
    sim, "Plt", "Platelets (NCI-CTCAE)", "#1b9e77",
    PLT_THRESHOLDS, pars$Plt0, dose_days
  )

  pdf(file, width = width, height = height)
  grid.arrange(p_neut, p_plt, ncol = 2,
               top = grid::textGrob(titre_base,
                                    gp = grid::gpar(fontface="bold",
                                                    fontsize=11)))
  dev.off()
  message("✓ Grades sauvegardés : ", file)

  # Statistiques résumées
  nadir_neut <- min(sim$Neut, na.rm = TRUE)
  nadir_plt  <- min(sim$Plt,  na.rm = TRUE)
  g_neut     <- nadir_grade_neut(sim$Neut)
  g_plt      <- nadir_grade_plt(sim$Plt)

  # % temps passé dans chaque grade (proxy de % patients)
  pct_neut <- sapply(1:4, function(g) {
    thr_lo <- c(0, NEUT_THRESHOLDS["G4"], NEUT_THRESHOLDS["G3"],
                NEUT_THRESHOLDS["G2"])[g]
    thr_hi <- c(NEUT_THRESHOLDS["G4"], NEUT_THRESHOLDS["G3"],
                NEUT_THRESHOLDS["G2"], NEUT_THRESHOLDS["G1"])[g]
    100 * mean(sim$Neut >= thr_lo & sim$Neut < thr_hi, na.rm=TRUE)
  })
  pct_plt <- sapply(1:4, function(g) {
    thr_lo <- c(0, PLT_THRESHOLDS["G4"], PLT_THRESHOLDS["G3"],
                PLT_THRESHOLDS["G2"])[g]
    thr_hi <- c(PLT_THRESHOLDS["G4"], PLT_THRESHOLDS["G3"],
                PLT_THRESHOLDS["G2"], PLT_THRESHOLDS["G1"])[g]
    100 * mean(sim$Plt >= thr_lo & sim$Plt < thr_hi, na.rm=TRUE)
  })

  invisible(list(
    nadir_neut       = nadir_neut,
    grade_nadir_neut = g_neut,
    pct_neut         = pct_neut,
    nadir_plt        = nadir_plt,
    grade_nadir_plt  = g_plt,
    pct_plt          = pct_plt
  ))
}

# ════════════════════════════════════════════════════════
# 4. SAVE_GRADE_FIGURE4C — humain population (Figure 4c)
#    Simule n_patients avec GFR variable → % par grade
# ════════════════════════════════════════════════════════
save_grade_figure4c <- function(base_pars, init_state,
                                auc_target = 5,
                                n_cycles   = 2,
                                interval_h = 21 * 24,
                                n_patients = 500,
                                gfr_mean   = 78,
                                gfr_sd     = 20,
                                file       = "Figure4c_grades.pdf",
                                titre      = "% patients par grade",
                                seed       = 42,
                                width      = 8,
                                height     = 5) {

  set.seed(seed)
  cat(sprintf("  → Figure 4c : %d patients (GFR~N(%g,%g) + IIV PK/PD)...\n",
              n_patients, gfr_mean, gfr_sd))

  times    <- seq(0, n_cycles * interval_h + 21*24, by = 1)
  gfr_vals <- pmax(20, pmin(150,
               rnorm(n_patients, mean = gfr_mean, sd = gfr_sd)))

  # IIV log-normale — variabilité inter-individuelle
  omega_CL      <- 0.40
  omega_V2      <- 0.40
  omega_Slope   <- 1.00
  omega_base    <- 0.35
  omega_MTT     <- 0.40
  omega_MTT_Plt <- 0.50
  omega_dPlt    <- 0.60
  omega_gamma   <- 0.40
  eta_CL    <- rnorm(n_patients, 0, omega_CL)
  eta_V2    <- rnorm(n_patients, 0, omega_V2)
  eta_Slope <- matrix(rnorm(n_patients * 3, 0, omega_Slope), nrow=n_patients)
  eta_Neut  <- rnorm(n_patients, 0, omega_base)
  eta_Plt   <- rnorm(n_patients, 0, omega_base)
  eta_MTT     <- rnorm(n_patients, 0, omega_MTT)
  eta_MTT_Plt <- rnorm(n_patients, 0, omega_MTT_Plt)
  eta_dPlt    <- rnorm(n_patients, 0, omega_dPlt)
  eta_gamma   <- rnorm(n_patients, 0, omega_gamma)

  grade_neut <- integer(n_patients)
  grade_plt  <- integer(n_patients)

  for (i in seq_len(n_patients)) {
    dose_i       <- auc_target * (gfr_vals[i] + 25)
    pars_i       <- base_pars
    pars_i$CL         <- base_pars$CL         * exp(eta_CL[i])
    pars_i$Slope_MPP  <- base_pars$Slope_MPP  * exp(eta_Slope[i,1])
    pars_i$Slope_CMP  <- base_pars$Slope_CMP  * exp(eta_Slope[i,2])
    pars_i$Slope_MEP  <- base_pars$Slope_MEP  * exp(eta_Slope[i,3])
    pars_i$Neut0      <- max(0.5, base_pars$Neut0 * exp(eta_Neut[i]))
    pars_i$Plt0       <- max(50,  base_pars$Plt0  * exp(eta_Plt[i]))
    pars_i$V2        <- max(5, base_pars$V2 * exp(eta_V2[i]))
    pars_i$MTT_Neut      <- max(50,  base_pars$MTT_Neut      * exp(eta_MTT[i]))
    pars_i$MTT_Plt       <- max(40,  base_pars$MTT_Plt       * exp(eta_MTT_Plt[i]))
    pars_i$delta_Plt     <- max(0.1, base_pars$delta_Plt     * exp(eta_dPlt[i]))
    pars_i$gamma_mat_CMP <- max(0.1, base_pars$gamma_mat_CMP * exp(eta_gamma[i]))
    pars_i$rate_fun <- make_repeated_infusion(
      dose_mg    = dose_i,
      Tinfu_h    = 1,
      interval_h = interval_h,
      n_cycles   = n_cycles
    )

    # État initial adapté aux baselines individuelles
    ss_T <- function(k, c0, mtt) k * c0 / (3 / mtt)
    state_i <- c(
      C1=0, C2=0, Damage=0,
      MPP=pars_i$MPP0, CMP=pars_i$CMP0, MEP=pars_i$MEP0,
      T1_Neut=ss_T(pars_i$k_circ_Neut,pars_i$Neut0,pars_i$MTT_Neut),
      T2_Neut=ss_T(pars_i$k_circ_Neut,pars_i$Neut0,pars_i$MTT_Neut),
      T3_Neut=ss_T(pars_i$k_circ_Neut,pars_i$Neut0,pars_i$MTT_Neut),
      Neut=pars_i$Neut0,
      T1_Mono=ss_T(pars_i$k_circ_Mono,pars_i$Mono0,pars_i$MTT_Mono),
      T2_Mono=ss_T(pars_i$k_circ_Mono,pars_i$Mono0,pars_i$MTT_Mono),
      T3_Mono=ss_T(pars_i$k_circ_Mono,pars_i$Mono0,pars_i$MTT_Mono),
      Mono=pars_i$Mono0,
      T1_Ret=ss_T(pars_i$k_circ_RBC,pars_i$Ret0,pars_i$MTT_Ret),
      T2_Ret=ss_T(pars_i$k_circ_RBC,pars_i$Ret0,pars_i$MTT_Ret),
      T3_Ret=ss_T(pars_i$k_circ_RBC,pars_i$Ret0,pars_i$MTT_Ret),
      Ret=pars_i$Ret0, RBC=pars_i$RBC0,
      T1_Plt=ss_T(pars_i$k_circ_Plt,pars_i$Plt0,pars_i$MTT_Plt),
      T2_Plt=ss_T(pars_i$k_circ_Plt,pars_i$Plt0,pars_i$MTT_Plt),
      T3_Plt=ss_T(pars_i$k_circ_Plt,pars_i$Plt0,pars_i$MTT_Plt),
      Plt=pars_i$Plt0
    )

    tryCatch({
      out_i <- as.data.frame(lsoda(
        y        = state_i,
        times    = times,
        func     = pkpd_fornari,
        parms    = pars_i,
        rtol     = 1e-6, atol = 1e-8,
        maxsteps = 100000
      ))
      grade_neut[i] <- nadir_grade_neut(out_i$Neut)
      grade_plt[i]  <- nadir_grade_plt(out_i$Plt)
    }, error = function(e) {
      grade_neut[i] <<- NA
      grade_plt[i]  <<- NA
    })

    if (i %% 100 == 0)
      cat(sprintf("    %d/%d patients\n", i, n_patients))
  }

  # % par grade (1 à 4)
  pct_neut <- sapply(1:4, function(g)
    100 * mean(grade_neut == g, na.rm = TRUE))
  pct_plt  <- sapply(1:4, function(g)
    100 * mean(grade_plt  == g, na.rm = TRUE))

  cat(sprintf("  Neutropénie  : G1=%.1f%%  G2=%.1f%%  G3=%.1f%%  G4=%.1f%%\n",
              pct_neut[1], pct_neut[2], pct_neut[3], pct_neut[4]))
  cat(sprintf("  Thrombopénie : G1=%.1f%%  G2=%.1f%%  G3=%.1f%%  G4=%.1f%%\n",
              pct_plt[1],  pct_plt[2],  pct_plt[3],  pct_plt[4]))

  # ── Barplot Figure 4c ─────────────────────────────────
  df_plot <- data.frame(
    Grade    = rep(paste0("G", 1:4), 2),
    Pct      = c(pct_neut, pct_plt),
    Lineage  = rep(c("Neutropenia", "Thrombocytopenia"), each = 4),
    stringsAsFactors = FALSE
  )
  df_plot$Grade   <- factor(df_plot$Grade,   levels = paste0("G", 1:4))
  df_plot$Lineage <- factor(df_plot$Lineage,
                            levels = c("Neutropenia", "Thrombocytopenia"))

  p <- ggplot(df_plot, aes(x = Grade, y = Pct, fill = Grade)) +
    geom_col(width = 0.65, alpha = 0.85) +
    geom_text(aes(label = sprintf("%.1f%%", Pct)),
              vjust = -0.4, size = 3) +
    facet_wrap(~ Lineage) +
    scale_fill_manual(values = unname(GRADE_COLORS), guide = "none") +
    scale_y_continuous(limits = c(0, max(df_plot$Pct) * 1.25),
                       labels = function(x) paste0(x, "%")) +
    labs(title = titre,
         subtitle = sprintf("AUC=%.0f  Q%dD×%d  n=%d patients  GFR~N(%g,%g²)",
                            auc_target, interval_h/24, n_cycles,
                            n_patients, gfr_mean, gfr_sd),
         x = "NCI-CTCAE v5.0 Grade",
         y = "% patients") +
    theme_bw(base_size = 10) +
    theme(strip.text      = element_text(face = "bold"),
          plot.title      = element_text(face = "bold", hjust = 0.5),
          plot.subtitle   = element_text(hjust = 0.5, size = 8,
                                         color = "grey40"),
          panel.grid.minor = element_blank())

  pdf(file, width = width, height = height)
  print(p)
  dev.off()
  message("✓ Figure 4c sauvegardée : ", file)

  invisible(list(pct_neut = pct_neut, pct_plt = pct_plt,
                 grade_neut = grade_neut, grade_plt = grade_plt))
}
